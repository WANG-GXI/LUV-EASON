#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"
/************************************************************************************
* ��ʱ������ (2020.5.11) WYD
* Description	:	
								
*************************************************************************************/

void TIM7_Int_Init(u16 arr,u16 psc);
void TIM6_Int_Init(u16 arr,u16 psc);
#endif
