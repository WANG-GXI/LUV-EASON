#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
/************************************************************************************
*   LED (2020.5.13) WYD			
* Description	:	
*************************************************************************************/
#define LED1 PEout(5)// PE5	
#define LED0 PBout(5)// PB5

void LED_Init(void);//��ʼ��

		 				    
#endif
