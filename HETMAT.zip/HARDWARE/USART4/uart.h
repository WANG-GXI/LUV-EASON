#ifndef UART4_H
#define UART4_H
#include "sys.h"

void uart4_Init(void);
void uart4_SendByte(unsigned char *DataToSend ,u8 data_num);
void USART1_Puts(char * str);
void USART4_SendData(uint8_t data);
void USART4_Writes(char *str);
void UART_HMI_Page_1(int FLAG);
extern  u8 com1_data;

#endif

